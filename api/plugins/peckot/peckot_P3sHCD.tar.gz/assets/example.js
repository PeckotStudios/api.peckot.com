console.log(blessing)
