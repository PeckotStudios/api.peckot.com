<?php

namespace XXX;

class Configuration
{
    public function render()
    {
        return view('xxx::config');
    }
}
